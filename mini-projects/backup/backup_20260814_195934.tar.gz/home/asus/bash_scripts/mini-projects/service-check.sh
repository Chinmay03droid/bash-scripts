#!/bin/bash

for service in "$@"
do
    echo "Checking service: $service"
done

echo "Total services: $#"
